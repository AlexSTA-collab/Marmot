## Marmot Module

This module is part of [Marmot](https://github.com/MAteRialMOdelingToolbox/Marmot).
Please refer to the [documentation](https://materialmodelingtoolbox.github.io/Marmot/) for details on the module system.
